import logging
import asyncio
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor

API_TOKEN = '7421878396:AAEdtng_O7ReFHYRX0gGHk_i9jZaZlHd0rY'
CHANNEL_USERNAME = '@avatarkin_channel'
TON_WALLET = 'UQBN67-NEOs38_VBk-ZLRFuJr30WGSxVOFTXCspTXM37603u'

logging.basicConfig(level=logging.INFO)

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

orders = {}
waiting_for_description = set()

@dp.message_handler(commands=['start'])
async def send_welcome(message: types.Message):
    await message.answer(
        "Привет! Я Аватаркин — бот, который создаёт уникальные аватары по описанию.\n"
        "Напиши /order чтобы начать заказ."
    )

@dp.message_handler(commands=['order'])
async def order_avatar(message: types.Message):
    user_id = message.from_user.id
    waiting_for_description.add(user_id)
    await message.answer("Опиши свой будущий аватар:")

@dp.message_handler(commands=['paid'])
async def handle_payment_confirmation(message: types.Message):
    user_id = message.from_user.id
    if user_id not in orders:
        await message.answer("Пожалуйста, сначала отправьте описание через /order.")
        return

    description = orders[user_id]

    avatars = [
        f"Ваш аватар (описание): {description} — вариант 1",
        f"Ваш аватар (описание): {description} — вариант 2",
        f"Ваш аватар (описание): {description} — вариант 3",
    ]

    for avatar in avatars:
        await message.answer(avatar)

    del orders[user_id]

@dp.message_handler()
async def handle_description(message: types.Message):
    user_id = message.from_user.id
    if user_id in waiting_for_description:
        description = message.text
        orders[user_id] = description
        waiting_for_description.remove(user_id)

        await message.answer(
            f"Описание принято: {description}\n"
            f"💸 Оплатите 5 TON на кошелёк:\n{TON_WALLET}\n"
            f"После оплаты пришлите команду /paid"
        )

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
